There is only one eclipse project - "Spark-Examples", which is created at the beginning of the book, i.e. chapter-1 and subsequently it is extended while moving ahead in the book.

"Spark-Examples" contains the code examples from chapter-1 till chapter-6. 
Chapter-7 does not have any new code examples. It re-uses the example�s created in previous chapters.

The package structure of each code example is self-explanatory and named after the chapters itself.
For instance all code examples in "Spark-Examples/chapter/one/" are for the first chapter  and so on. 


You can also import the "Spark-Examples" as the eclipse project but do remember to change the location of dependent jar files in ".classpath" file.

Rest all instructions are there in the chapter itself for executing the examples on a single node Spark cluster.

Feel free to email me sumit1001@gmail.com in case you see any issues with the provided code examples.

